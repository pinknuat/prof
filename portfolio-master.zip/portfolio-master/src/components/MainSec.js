import React from "react";
import rocket from "../img/title2.png";
class MainSec extends React.Component {
  render() {
    return (
      <div className="mainbody">
        <div className="row">
          <div className="column leftr">
            <h1 className="titles" id="top">
              Elevate your Endeavour
            </h1>
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>{" "}
            <p>
              The manifestation of an idea is one of the most powerful things a
              human being can do. At Omnified Tech, we aim to bring your ideas
              to life through the power of web/application development. Let us
              help you share your great ideas with the world. From brainstorming
              to making youssssssssssssssssssssssssssssssssssssssssssssr site a
              live page on the internet: we are here for you.
            </p>
          </div>
          <div className="column rightr">
            <div className="centerimages">
              <img
                data-aos="fade-up"
                data-aos-duration="00"
                className="rocket"
                alt="rocket"
                src={rocket}
              />
            </div>
          </div>
        </div>
        <h1 className="spacetoph1 spacebottom">Previous Projects</h1>
      </div>
    );
  }
}

export default MainSec;
